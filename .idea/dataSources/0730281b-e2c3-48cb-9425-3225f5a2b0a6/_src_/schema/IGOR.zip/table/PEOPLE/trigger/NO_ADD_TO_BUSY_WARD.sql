create trigger NO_ADD_TO_BUSY_WARD
	before insert
	on PEOPLE
	for each row
Declare
  v_busyPlaces Number;
  v_maxPlaces Number;
  v_emptyPlaces Number;
Begin
  
  Select Count(People.peopleId) Into v_busyPlaces
  From Wards
  inner join People on People.wardId = Wards.wardId
  Where Wards.wardId = :new.wardId;
  
  Select Wards.maxCount into  v_maxPlaces
  From Wards
  Where Wards.wardId = :new.wardId;
  
  v_emptyPlaces := v_maxPlaces - v_busyPlaces;
  
  if (v_emptyPlaces < 0) then
   raise_application_error( -20001, 'THIS ward is busy');
  end if;
  
End no_add_to_busy_ward;