create Procedure leastRatioPlace
(
  c_v_wardId IN Number,
  
  v_result1 Out Number,
  v_result2 Out Number
) as
v_departureId Number;
Begin
  Select Departures.departureId
  Into v_departureId
  From Wards
  inner join Departures on Departures.departureId = Wards.departureId
  Where Wards.wardId = c_v_wardId;
  
  
  Select Min(res)
  Into v_result1
  From (Select Wards.wardId,Wards.wardName, Wards.maxCount, Count(People.peopleId) / Wards.maxCount as res
    From Wards, Diagnosis, People
    Where Wards.wardId = People.wardId And People.diagnosisId = Diagnosis.diagnosisId and Wards.departureId = v_departureId
    Group by Wards.wardId,Wards.wardName, Wards.maxCount);

  Select Min(res)
  Into v_result2
  From (Select Wards.wardId,Wards.wardName, Wards.maxCount, Count(People.peopleId) / Wards.maxCount as res
    From Wards, Diagnosis, People
    Where Wards.wardId = People.wardId And People.diagnosisId = Diagnosis.diagnosisId and Wards.departureId != v_departureId
    Group by Wards.wardId,Wards.wardName, Wards.maxCount);    
End;