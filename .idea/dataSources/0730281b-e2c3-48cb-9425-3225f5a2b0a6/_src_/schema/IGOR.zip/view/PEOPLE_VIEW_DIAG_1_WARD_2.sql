create view PEOPLE_VIEW_DIAG_1_WARD_2 as
Select People.firstName, People.lastName, People.fatherName, Diagnosis.diagnosisName, Wards.wardName
From People, Wards, Diagnosis
Where People.wardId = Wards.wardId and People.diagnosisId = Diagnosis.diagnosisId
and People.wardId = 2 and People.diagnosisId = 1
With Read Only
