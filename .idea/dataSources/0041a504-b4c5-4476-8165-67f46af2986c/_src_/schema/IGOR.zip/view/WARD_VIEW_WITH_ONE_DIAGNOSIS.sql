create view WARD_VIEW_WITH_ONE_DIAGNOSIS as
Select Wards.wardName
From Wards, People
Where People.wardId = Wards.wardId
Group By Wards.wardName, Wards.wardId
Having Count(distinct People.diagnosisId) = 1
With Read Only
