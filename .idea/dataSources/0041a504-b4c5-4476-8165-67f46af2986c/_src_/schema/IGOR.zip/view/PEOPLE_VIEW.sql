create view PEOPLE_VIEW as
Select People.firstName, People.lastName, People.fatherName, Diagnosis.diagnosisName, Wards.wardName
From People, Wards, Diagnosis
Where People.wardId = Wards.wardId and People.diagnosisId = Diagnosis.diagnosisId
With Read Only
