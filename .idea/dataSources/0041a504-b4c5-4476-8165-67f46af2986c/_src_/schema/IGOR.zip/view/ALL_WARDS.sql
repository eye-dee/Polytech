create view ALL_WARDS as
Select Wards.wardName as "Номер палаты", Wards.maxCount as "Вместимость", Count(People.peopleId) as "Занято", Diagnosis.diagnosisName as "Диагноз"
From Wards,Departures,People, Diagnosis
Where Wards.wardId = People.wardId and Departures.departureId = Wards.departureId and Diagnosis.diagnosisId = People.diagnosisId
Group by Wards.wardName, Wards.maxCount, Diagnosis.diagnosisName
With Read Only
