create trigger NO_EQUIVALENT_DIAGNOSIS
	before insert
	on DIAGNOSIS
	for each row
Declare
  v_amountCurrentDiagnosis Number;
Begin

  Select Count(Diagnosis.diagnosisId) into v_amountCurrentDiagnosis
  From Diagnosis
  Where Diagnosis.diagnosisName = :new.diagnosisName;


  if (v_amountCurrentDiagnosis > 0) then
   raise_application_error( -20001, 'THIS diagnosis is already exists');
  end if;
  
End no_equivalent_diagnosis;