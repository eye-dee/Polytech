create trigger NO_ADD_PEOPLE_WITH_EMPTY_NAMES
	before insert
	on PEOPLE
	for each row
Declare
Begin
  if (:new.lastName is null or :new.firstName is null or :new.fatherName is null) then
   raise_application_error( -20001, 'Cant create people with empty name');
  end if;
  
End no_add_people_with_empty_names;